-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2021 at 08:05 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `travelguide`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `aname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aname`, `password`) VALUES
('Divya', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `bookpackages`
--

CREATE TABLE IF NOT EXISTS `bookpackages` (
  `userid` varchar(100) NOT NULL,
  `places` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `Staycost` int(16) NOT NULL,
  `Foodcost` int(16) NOT NULL,
  `Travellingcost` int(16) NOT NULL,
  `Totalamount` int(16) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookpackages`
--

INSERT INTO `bookpackages` (`userid`, `places`, `date`, `Staycost`, `Foodcost`, `Travellingcost`, `Totalamount`) VALUES
('USR1', 'Mumbai', '2021-03-28', 4050, 300, 3150, 7500),
('USR2', 'Punjab', '2021-04-02', 4050, 300, 3150, 7500);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `imid` int(29) NOT NULL,
  `image` blob NOT NULL,
  `pid` int(11) NOT NULL,
  `place` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `noofdays` int(11) NOT NULL,
  `noofnights` int(11) NOT NULL,
  PRIMARY KEY (`imid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `image`
--


-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `Userid` varchar(100) NOT NULL,
  `mode` varchar(100) NOT NULL,
  `cardno` varchar(16) NOT NULL,
  `cvvno` varchar(3) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Userid`, `mode`, `cardno`, `cvvno`, `month`, `year`) VALUES
('USR1', 'Debit Card', '1234567892345674', '234', 12, 2023),
('USR2', 'Credit Card', '1234567891011223', '678', 9, 2024);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `userid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobileno` varchar(16) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`userid`, `password`, `name`, `mobileno`, `email`) VALUES
('USR1', '123', 'simran', '9881758855', 'simranduggal75@gmail.com'),
('USR2', '1234', 'prerna', '9921975855', 'prerna25@gmail.com');
