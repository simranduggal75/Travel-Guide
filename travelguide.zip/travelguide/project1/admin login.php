<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$conn = mysqli_connect('localhost','root','');
mysqli_select_db($conn, 'travelguide');
$aname = $_POST['aname'];
$password = $_POST['password'];

$sql = "select * from admin where aname = '$aname' && password = '$password'";
$result = mysqli_query($conn, $sql);
$num = mysqli_num_rows($result);

if($num == 1)
{
header('location:add tour packages.php');
}
else
{
header('location:admin login.php');
}
}
?>
<html>
<head>
<title>Admin Login</title>
<style>
body
{
margin:0;
background-color:powderblue;

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 1000px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 20px;
float:left;
padding: 20px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
</style>
</head>
<body>

<div class="nav">
<ul>
<li><a href="Index.php">Home</a></li>
<li><a href="about us.php">About Us</a></li>
<li><a href="contact us.php">Contact Us</a></li>
<li><a href="Lg.php">Login</a></li>
</ul>
</div><br>
<center>
<img src="alogo.jpg"><br><br>
<form action="<?php echo($_SERVER["PHP_SELF"]); ?>" method="post">
<table>
<tr>
<td><b>Admin Name</b></td><br>
<td>
<input type="text" name="aname" placeholder="Enter Admin name"  required><br><br>
</td>
</tr>
<tr>
<td><b>Password</b></td>
<td>
<input type="password" name="password" placeholder="Enter Password"  required><br><br>
</td>
</tr>
<td>
<input type="submit" name="submit" value="Login" 
style="font-weight:bold; margin:25px; padding:10px; 
text-align:center;display:flex;justify-content:center; margin-top:28px; font-size:15px; margin-bottom:9px">
</td>
</tr>
</table>
</form>
</center>
</body>
</html>