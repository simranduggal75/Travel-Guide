<html>
<head>
<title>About Us</title>
<style>
body
{
margin:0;
background-color:powderblue;

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 1000px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 20px;
float:left;
padding: 20px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
</style>
</head>
<body>

<div class="nav">
<ul>
<li><a href="Index.php">Home</a></li>
<li><a href="about us.php">About Us</a></li>
<li><a href="contact us.php">Contact Us</a></li>
<li><a href="Lg.php">Login</a></li>
</ul>
</div><br>
<center>
<img src="tg.jpg" style="height:400px"><br><br>
<br><br>
<h2><b> Travel guide is created for the users to search and apply for travel service. The system also has admin panel
where admin can add tour packages,view package details,view user details,view booking details,
view payment details.The system allows the user to check various travel destinations 
and choose his/her destinations accordingly. User can select desired packages as per entered location and 
accordingly can have their bookings.User can pay the bill using Credit Card/Debit Card.</h2><b>
</center>
</body>
</html>