<html>
<head>
<title>PhotoGall</title>
<style>
body
{
margin:0;
background-color:powderblue;
width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 900px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items:center;
padding: 5px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:25px;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 10px;
margin-left: 10px;
float:left;
padding: 5px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 20px;

}
a:hover
{
background-color:white;
}
.gallery
{
float:left;
width: 24%;
margin: 80px;

}
.des
{
padding: 15px;
text-align:center;
font-family: 'Poppins', sans-serif;
font-size: 15px ;
font-weight: bold;
}
</style>
</head>
<body>
<div class="nav">
<ul>
<li><a href="photogall.php">View Place</a></li>
<li><a href="book packages.php">Book packages</a></li>
<li><a href="payment.php">Payment</a></li>
<li><a href="Lg.php">Logout</a></li>
</ul>
</div>
<div class="responsive">
<div class="gallery">

<img src="mumbai.jpg" width="350" height="200">
<div class="des">Mumbai<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="goa1.jpg" width="350" height="200">
<div class="des">Goa<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="kerala1.jpg" width="350" height="200">
<div class="des">Kerala<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="kashmir.jpg" width="350" height="200">
<div class="des">Kashmir<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="rajasthan1.jpg" width="350" height="200">
<div class="des">Rajasthan<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="agra1.jpg" width="350" height="200">
<div class="des">Agra<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="karnataka.jpg" width="350" height="200">
<div class="des">Karnataka<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="mp.jpg" width="350" height="200">
<div class="des">Madhya Pradesh<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="punjab1.jpg" width="350" height="200">
<div class="des">Punjab<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="kolkata.jpg" width="350" height="200">
<div class="des">Kolkata<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="tn.jpg" width="350" height="200"></a>
<div class="des">Tamil Nadu<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>
<div class="responsive">
<div class="gallery">
<img src="hp.jpg" width="350" height="200">
<div class="des">Himachal Pradesh<br>Number of Days:4 Days 3 Nights<br>Rs.7500</div>
</div>
</div>

</div>
</body>
</html>
<?php
$con = mysqli_connect("localhost","root","");
$db=mysqli_select_db($con,'travelguide');

$res=mysqli_query($con,"select * from image");

//echo "<table>";
while($row=mysqli_fetch_array($res))
{
//echo "<tr>";
//echo "<td>";

$image=base64_encode($row['image']);
$place=$row["place"];
$price=$row["price"];
$noofdays=$row["noofdays"];
$noofnights=$row["noofnights"];

echo "<div class='responsive'>
<div class='gallery'>
<img src='data:image/jpeg;base64,$image' width='350' height='200'>
<div class='des'>$place<br>Number of Days/Nights: $noofdays Days $noofnights Nights<br>$price</div>
</div>
</div>
";
/*
echo "<img src='data:image/jpeg;base64,$image'  width='350' height='200'/>";echo "</td>";
echo "<td>"; echo $row["place"]; echo "</td>";
echo "<td>"; echo $row["price"]; echo "</td>";
echo "<td>"; echo $row["noofdays"]; echo "</td>";
echo "<td>"; echo $row["noofnights"]; echo "</td>";

echo "</tr>";
*/
}
echo"</table>";
?>