<html>
<head>
<style>
body
{
margin:0;
background-color:powderblue;

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 1100px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 5px;
float:center;
padding: 5px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
input
{
width:20%;
height:5%;
border:1px;
border-radius:5px;
padding:8px 15px 8px 15px;
margin:10px 0px 15px 0px;
box-shadow:1px 1px 2px 1px grey;
font-weight:bold;
}
table,th,td{
border:2px solid black;
width:1000px;
background-color:powderblue;
}
.btn
{
width:20%;
height:5%;
font-size:22px;
padding:0px;
}
</style>
</head>

<body>
<div class="nav">
<ul>
<li><a href="add tour packages.php">ADD TOUR PACKAGES</a></li>
<li><a href="view package details.php">VIEW PACKAGE DETAILS</a></li>
<li><a href="view booking details.php">VIEW BOOKING DETAILS</a></li>
<li><a href="view user details.php">VIEW USER DETAILS</a></li>
<li><a href="view payment details.php">VIEW PAYMENT DETAILS</a></li>
<li><a href="Lg.php">LOGOUT</a></li>
</ul>
</div>
<center><h2>View Payment Details</h2>
<form action="" method="POST">
<input type="text" name="Userid" class="btn" placeholder="Enter userid">
<input type="submit" name="search" class="btn" value="Search by id">
</form>

<table>
<tr>
<th>userid</th>
<th>Payment Mode</th>
<th>Card No</th>
<th>CVV No</th>
<th>Month</th>
<th>Year</th>
</tr>
</center>
<br>
<?php
$connection=mysqli_connect("localhost","root","");
$db=mysqli_select_db($connection,'travelguide');
if(isset($_POST['search']))
{
$Userid=$_POST['Userid'];
$query="SELECT *FROM payment where Userid='$Userid'";
$query_run=mysqli_query($connection,$query);

while($row=mysqli_fetch_array($query_run))

{
?>
<tr>
<td><?php echo $row['Userid']?></td>
<td><?php echo $row['mode']?></td>
<td><?php echo $row['cardno']?></td>
<td><?php echo $row['cvvno']?></td>
<td><?php echo $row['month']?></td>
<td><?php echo $row['year']?></td>
</tr>
<?php
}
}
?>

</table>
</body>
</html>