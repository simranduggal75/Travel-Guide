<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'travelguide');

if(isset($_POST["submit"]))
{
$userid = $_POST["userid"];
$places = $_POST["places"];
$date = $_POST["date"];
$Staycost = $_POST["Staycost"];
$Foodcost = $_POST["Foodcost"];
$Travellingcost = $_POST["Travellingcost"];
$Totalamount = $_POST["Totalamount"];

$query = "insert into bookpackages(userid,places,date,Staycost,Foodcost,Travellingcost,Totalamount)VALUES('$userid','$places','$date','$Staycost','$Foodcost','$Travellingcost','$Totalamount')";

$query_run = mysqli_query($connection,$query);

if($query_run)
{
echo "Record ADDEDD";
}
else
{
echo "Record FAILEDD";
}
}
?>
<html>
<head>
<title>Book Packages</title>
</head>
<body style="background-color:powderblue">
<style>
body
{
margin:0;
background-color:powderblue;
width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 900px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items:center;
padding: 5px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:25px;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right:10px;
margin-left: 10px;
float:left;
padding: 5px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 20px;

}
a:hover
{
background-color:white;
}
.gallery
{
float:left;
width: 24%;
margin: 80px;

}
.des
{
padding: 15px;
text-align:center;
font-family: 'Poppins', sans-serif;
font-size: 15px ;
font-weight: bold;
}
</style>
</head>
<body>
<div class="nav">
<ul>
<li><a href="photogall.php">View Place</a></li>
<li><a href="book packages.php">Book packages</a></li>
<li><a href="payment.php">Payment</a></li>
<li><a href="Lg.php">Logout</a></li>
</ul>
</div><br><br>
<form action="" method="POST"><center>
User id
<input type="text" name="userid" placeholder="enter user id"><br><br><br>
SELECT PLACES
<select name="places">
<option value="">---select---</option>
<option value="Mumbai">Mumbai</option>
<option value="Agra">Agra</option>
<option value="Goa">Goa</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Kolkata">Kolkata</option>
<option value="Karnataka">Karnataka</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Kerala">Kerala</option>
<option value="Madhya Pradesh">Madhya Pradesh</option> 
</select><br><br><br>

Date
<input type="date" name="date"><br><br><br>

STAY COST
<select name="Staycost">
<option value="">---select--</option>
<option value="4050 ">4050</option><br><br>
</select><br><br><br>

FOOD COST
<select name="Foodcost">
<option value="">---select--</option>
<option value="300 ">300</option><br><br>
</select><br><br><br>

TRAVELLING COST
<select name="Travellingcost">
<option value="">---select--</option>
<option value="3150 ">3150</option><br><br>
</select><br><br><br>

TOTAL AMOUNT
<select name="Totalamount">
<option value="">---select--</option>
<option value="7500 ">7500</option><br><br>
</select><br><br><br>

<input type="submit" name="submit" value="Submit" style="font-weight:bold; margin:25px; padding:10px; 
text-align:center;display:flex;justify-content:center; margin-bottom:10px">
</form>
</center>
</body>
</html>

