<html>
<head>
<style>
body
{
margin:0;
background-color:powderblue;

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 1100px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 5px;
float:center;
padding: 5px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
input
{
width:20%;
height:5%;
border:1px;
border-radius:5px;
padding:8px 15px 8px 15px;
margin:10px 0px 15px 0px;
box-shadow:1px 1px 2px 1px grey;
font-weight:bold;
}
</style>
</head>

<body>
<div class="nav">
<ul>
<li><a href="add tour packages.php">ADD TOUR PACKAGES</a></li>
<li><a href="view package details.php">VIEW PACKAGE DETAILS</a></li>
<li><a href="view booking details.php">VIEW BOOKING DETAILS</a></li>
<li><a href="view user details.php">VIEW USER DETAILS</a></li>
<li><a href="view payment details.php">VIEW PAYMENT DETAILS</a></li>
<li><a href="Lg.php">LOGOUT</a></li>
</ul>
</div>
<center><h2>ADD TOUR PACKAGES</h2><br><br>
<form method="POST" enctype="multipart/form-data">
ADD PHOTO
<center>
Choose an profile pic<br>
<input type="file" name="image" id="image"><br>
PACKAGE ID
<input type="text" name="pid"><br><br><br>
ADD PLACE
<input type="text" name="place"><br><br><br>
PRICE
<input type="text" name="price"><br><br><br>
NUMBER OF DAYS
<select id="noofdays" name="noofdays">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
</select><br><br><br>

 NUMBER OF NIGHTS
<select id="noofnights" name="noofnights">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
</select><br><br><br>
<input type="submit" name="submit" value="SUBMIT">

</form>
</body>
</html>

<?php
$connection=mysqli_connect("localhost","root","");
$db=mysqli_select_db($connection,'travelguide');

if(isset($_POST['submit']))
{
$file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
$pid=$_POST["pid"];
$place=$_POST["place"];
$price=$_POST["price"];
$noofdays=$_POST["noofdays"];
$noofnights=$_POST["noofnights"];

$query="INSERT INTO image (image,pid,place,price,noofdays,noofnights) VALUES('$file','$pid','$place','$price','$noofdays','$noofnights')";
$query_run=mysqli_query($connection,$query);
if($query_run)
{
echo '<script type="text/javascript"> alert("photo uploaded") <script>';
}
else
{
echo '<script type="text/javascript"> alert("photo not uploaded") <script>';
}
}
?>


