<html>
<head>
<style>
table
{
font-family:arial,sans-serif;
border-collapse:collapse;
width:100%;
}
td,th
{
border:1px solid #dddddd;
text-align:left;
padding:8px;
}
tr:nth-child(even)
{
background-color:#dddddd;
}
body
{
margin:0;
background-color:powderblue;

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 1100px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 5px;
float:center;
padding: 5px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;

}
a:hover
{
background-color:white;
}

input
{
width:50%;
height:5%;
border:1px;
border-radius:5px;
padding:8px 15px 8px 15px;
margin:10px 0px 15px 0px;
box-shadow:1px 1px 2px 1px grey;
font-weight:bold;
}
</style>
</head>
<body>
<div class="nav">
<ul>
<li><a href="add tour packages.php">ADD TOUR PACKAGES</a></li>
<li><a href="view package details.php">VIEW PACKAGE DETAILS</a></li>
<li><a href="view booking details.php">VIEW BOOKING DETAILS</a></li>
<li><a href="view user details.php">VIEW USER DETAILS</a></li>
<li><a href="view payment details.php">VIEW PAYMENT DETAILS</a></li>
<li><a href="Lg.php">LOGOUT</a></li>
</ul>
</div>
<center><h2>VIEW PACKAGE DETAILS</h2></center><br><br>

<table>
<tr>
<th>PLACE</th>
<th>Stay cost</th>
<th>Food cost</th>
<th>Travelling cost</th>
<th>Number of days</th>
<th>Total amount</th>
<th>Image</th>

<tr>
<td>Mumbai</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="mumbai.jpg"></td>
</tr>
<tr>
<td>Goa</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="goa1.jpg"></td>
</tr>
<tr>
<td>Kerala</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="kerala1.jpg"></td>
</tr>
<tr>
<td>Kashmir</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="kashmir.jpg"></td>
</tr>

<tr>
<td>Rajasthan</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="rajasthan1.jpg"></td>
</tr>

<tr>
<td>Agra</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="agra1.jpg"></td>
</tr>

<tr>
<td>Karnataka</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="karnataka.jpg"></td>
</tr>

<tr>
<td>Madhya Pradesh</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="mp.jpg"></td>
</tr>

<tr>
<td>Punjab</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="punjab1.jpg"></td>
</tr>

<tr>
<td>Kolkata</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="kolkata.jpg"></td>
</tr>

<tr>
<td>Tamil Nadu</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="tn.jpg"></td>
</tr>

<tr>
<td>Himachal Pradesh</td>
<td>4050</td>
<td>300</td>
<td>3150</td>
<td>4D/3N</td>
<td>7500</td>
<td><img src="hp.jpg"></td>
</tr>

</table>
</body>
</html>
