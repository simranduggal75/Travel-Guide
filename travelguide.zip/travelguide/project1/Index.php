<html>
<head>
<title>Index</title>
<style>
body
{
margin:0;
background-image: url(bg.jpg);

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}

 .nav
{
width: 900px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 20px;
float:left;
padding: 20px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
</style>
</head>
<body>

<div class="nav">
<ul>
<li><a href="Index.php">Home</a></li>
<li><a href="about us.php">About Us</a></li>
<li><a href="contact us.php">Contact Us</a></li>
<li><a href="Lg.php">Login</a></li>
</ul>
</div>
</body>
</html>