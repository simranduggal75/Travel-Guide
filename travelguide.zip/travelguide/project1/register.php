<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "travelguide";
$conn = mysqli_connect($servername,$username,$password,$dbname);
?>
<?php
$query = "select * from register order by userid desc limit 1";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);
$lastid = $row['userid'];
if($lastid ==" ")
{
$usrid = "USR1";
}
else
{
$usrid = substr($lastid,3);
$usrid = intval($usrid);
$usrid = "USR" . ($usrid + 1);
}
?>
<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$user = $_POST['user'];
$pass = $_POST['pass'];
$nm = $_POST['nm'];
$pho = $_POST['pho'];
$mail = $_POST['mail'];

if(!$conn)
{
die("connection failed" . mysqli_connect_error());
}
else
{
$sql = "insert into register(userid,password,name,mobileno,email)VALUES('$user','$pass','$nm','$pho','$mail')";

if(mysqli_query($conn,$sql))
{
echo "Record ADDEDD";
}
else
{
echo "Record FAILEDD";
}
}
}
?>
<html>
<head>
<title>Register</title>
<style>
body
{
margin:0;
background-color:powderblue;

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 1000px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 20px;
float:left;
padding: 20px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
</style>
</head>
<body>
<div class="nav">
<ul>
<li><a href="Index.php">Home</a></li>
<li><a href="">About Us</a></li>
<li><a href="">Contact Us</a></li>
<li><a href="Lg.php">Login</a></li>
</ul>
</div>
<center>
<h1>Registeration</h1>
<form action="<?php echo($_SERVER["PHP_SELF"]); ?>" method="post">
<table>
<tr>
<td><b>User Id</b></td>
<td>
<input type="text" name="user" required style="color:darkgreen; font-weight:bold" value="<?php echo $usrid; ?>" readonly><br><br>
</td>
</tr>
<tr>
<td><b>Password</b></td>
<td>
<input type="password" name="pass" placeholder="Enter Password"  required><br><br>
</td>
</tr>
<tr>
<td><b>Name</b></td>
<td>
<input type="text" name="nm" placeholder="Enter Your Name"  required><br><br>
</td>
</tr>
<tr>
<td><b>Mobile Number</b></td>
<td>
<input type="phone" name="pho" placeholder="Enter 10 digit Mobile No"  required><br><br>
</td>
</tr>
<tr>
<td><b>Email-Id</b></td>
<td>
<input type="email" name="mail" placeholder="Enter your Email-Id"  required><br><br>
</td>
</tr>
</table>

<input type="button" name="back" value="Back" onclick="location.href='userlogin.php'" style="font-weight:bold;
 margin:25px; padding:10px; text-align:center; margin-bottom:10px">

<input type="submit" name="submit" value="Submit" style="font-weight:bold; margin:25px; padding:10px; 
text-align:center;display:flex;justify-content:center; margin-bottom:10px">

<input type="reset" name="reset" value="Reset" style="font-weight:bold; margin:25px; padding:10px; 
text-align:center;display:flex;justify-content:center; margin-bottom:10px">


</form>
</center>
</body>
</html>