<html>
<head>
<title>Contact Us</title>
<style>
body
{
margin:0;
background-color:powderblue;

width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 1000px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 20px;
float:left;
padding: 20px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
h3
{
width:400px;
margin:3px;
background-color:#DAF7A6;
border: 2px solid;
margin-right: 300px;
margin-left:650px;
padding:22px;
text-align:center;

font-family: 'Poppins', sans-serif; font-size:20px;
}
</style>
</head>
<body>

<div class="nav">
<ul>
<li><a href="Index.php">Home</a></li>
<li><a href="about us.php">About Us</a></li>
<li><a href="contact us.php">Contact Us</a></li>
<li><a href="Lg.php">Login</a></li>
</ul>
</div><br><br>
<img src="tg.jpg" style="height:400px">
<br><br>
<h3> Developed By-<br><br>
    Name: Simran Duggal<br><br>
    Name: Divya Nair<br><br>
Email: simranduggal75@gmail.com<br><br>
Email: divya.2000rpn@gmail.com<br><br>
Mobile No: 9881758855<br><br>
Mobile No: 8830936219<br><br>
</h3>
</center>


</body>
</html>