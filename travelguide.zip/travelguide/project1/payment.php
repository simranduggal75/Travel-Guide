<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'travelguide');

if(isset($_POST["submit"]))
{
$Userid = $_POST["Userid"];
$mode = $_POST["mode"];
$cardno= $_POST["cardno"];
$cvvno = $_POST["cvvno"];
$month = $_POST["month"];
$year = $_POST["year"];

$query = "insert into payment(Userid,mode,cardno,cvvno,month,year)VALUES('$Userid','$mode','$cardno','$cvvno','$month','$year')";
          
$query_run = mysqli_query($connection,$query);

if($query_run)
{
echo "Transaction Successful";
}
else
{
echo "Transaction Unsuccessful";
}
}
?>
<html>
<head>
<title>Payment</title>
</head>
<body style="background-color:powderblue">
<style>
body
{
margin:0;
background-color:powderblue;
width: 100%;
background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}
 .nav
{
width: 900px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items:center;
padding: 5px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:25px;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 10px;
margin-left: 10px;
float:left;
padding: 5px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 20px;

}
a:hover
{
background-color:white;
}
.gallery
{
float:left;
width: 24%;
margin: 80px;

}
.des
{
padding: 15px;
text-align:center;
font-family: 'Poppins', sans-serif;
font-size: 15px ;
font-weight: bold;
}
table,th,td
{
border: 2px solid black;
width: 600px;
}
</style>
</head>
<body><center>
<div class="nav">
<ul>
<li><a href="photogall.php">View Place</a></li>
<li><a href="book packages.php">Book packages</a></li>
<li><a href="payment.php">Payment</a></li>
<li><a href="Lg.php">Logout</a></li>
</ul>
</div><br><br>

<table>
<tr>
<th> Stay Cost</th>
<th> Food Cost</th>
<th> Travelling Cost</th>
<th> Total Amount</th>
</tr>
<tr>
<th> Rs.4050 </th>
<th> Rs.300 </th>
<th> Rs.3150 </th>
<th> Rs.7500 </th>
</tr>
</table><br><br><br>
<form method="POST">
<b>User ID</b>
<input type="text" name="Userid" placeholder="Enter user id"><br><br><br>
<b>Payment Mode</b>
<select name="mode">
<option value="">---select---</option>
<option value="Credit Card">Credit Card</option>
<option value="Debit Card">Debit Card</option>
</select><br><br><br><br>
<b>Card No</b>
<input type="text" name="cardno" placeholder="Enter 16 Digit Card No"><br><br><br>
<b>CVV No</b>
<input type="text" name="cvvno" placeholder="Enter 3 Digit CVV No"><br><br><br>
<b>Expiry Date</b>
<select name="month">
<option value="Month">Month</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>
<select name="year">
<option value="Year">Year</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2030">2030</option>
</select>
<input type="submit" name="submit" value="Pay" style="font-weight:bold; margin:25px; padding:10px; 
text-align:center;display:flex;justify-content:center; margin-bottom:10px;width:100px">
</form>