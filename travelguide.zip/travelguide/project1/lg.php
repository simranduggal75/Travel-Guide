<html>
<head>
<title>Login</title>
<style>
body
{
margin:0;
background-image: url(bg.jpg);

background-position: center;
background-size: cover;
position: absolute;
font-family: 'Poppins', sans-serif;
}

 .nav
{
width: 1000px;
background-color:#DAF7A6;
margin:auto;
overflow:auto;
display: flex;
align-items: center;
padding: 20px;
}
ul
{
display: inline-block;
list-style-type: none;
margin:0;
padding:0;
list-style:none;
}
li
{
display: inline-block;
margin-right: 20px;
float:left;
padding: 20px;
}
a:link
{
color:white;
width:125px;
text-decoration:none;
display:block;
text-align:center;
padding:15px;
text-transform:uppercase;
font-size: 18px;
}
a:hover
{
background-color:white;
}
.btn
{
width:200px;
height:50px;
border-radius: 30px;
background-color:#DAF7A6;
border: 2px solid;
padding:25px;
margin:150px;;
font-family: 'Poppins', sans-serif;
font-size: 20px
}
.btn1
{
width:200px;
height:50px;
border-radius: 30px;
background-color:#DAF7A6;
border: 2px solid;
padding:25px;
margin:150px;
font-family: 'Poppins', sans-serif;
font-size:20px;
}
</style>
</head>
<body>

<div class="nav">
<ul>
<li><a href="Index.php">Home</a></li>
<li><a href="about us.php">About Us</a></li>
<li><a href="contact us.php">Contact Us</a></li>
<li><a href="lg.php">Login</a></li>
</ul>
</div>
</div>
<center>
<input type=button value="ADMIN" onclick="location.href='admin login.php'"style="width:200px; height:50px;
border-radius: 30px; background-color:#DAF7A6; border: 2px solid; padding:25px; margin:150px; 
font-family: 'Poppins', sans-serif; font-size:20px; text-align:center; font-weight:bold">

<input type=button value="USER" onclick="location.href='userlogin.php'"style="width:200px; height:50px;
border-radius: 30px; background-color:#DAF7A6; border: 2px solid; padding:25px; margin:150px; 
font-family: 'Poppins', sans-serif; font-size:20px; text-align:center; font-weight:bold">
</center>
</body>
</html>